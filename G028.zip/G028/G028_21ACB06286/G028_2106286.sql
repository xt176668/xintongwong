/*
File to submit by each member: G028_2106286.sql

INDIVIDUAL ASSIGNMENT SUBMISSION
Submit one individual report with SQL statements only (*.docx)
and one sql script (*.sql for oOacle)

Template save as "G999_YourStudentID.sql"
e.g. G001_999999.sql

GROUP NUMBER : G028
PROGRAMME : CS
STUDENT ID :2106286
STUDENT NAME :Chang Joo Yee
Submission date and time: 16-Apr-24

Your information should appear in both files one individual report docx & one individual sql script, then save as G01_99ACB999999.zip
Should be obvious different transaction among the members

*/



/* Query 1 */
------List the food items with prices less than RM20.00 and sort the price and food category name in ascending order.

SELECT f.itemid,f.foodName AS "Food Name",'RM'||to_char(f.foodunitprice,'999.99') AS Price,fc.foodcategoryname AS Category,fquantity AS Quantity
FROM fooditem f 
JOIN food_category fc
ON f.foodcategoryid = fc.foodcategoryid
WHERE f.foodunitprice <20
ORDER BY Price ASC,Category ASC;

/* Query 2 */
------List the details of the current contract employees managed by the manager, whose manager ID is E015.

SELECT ce.personID AS employeeID,
p.firstName || ' ' || p.lastName AS Name,
 p.phoneNo AS phoneNumber,
p.personDOB AS DateOfBirth,
p.Gender,
e.totalSalary AS "Total Salary",
ce.contractStartDate AS "Hire Date",
ce.contractEndDate AS "End Date"
FROM CONTRACT_EMPLOYEE ce
JOIN PERSON p ON ce.personID = p.personID
JOIN EMPLOYEE e ON ce.personID = e.personID
WHERE ce.mgrID = 'E015'
AND contractEndDate>=sysdate;

/* Query 3 */
------Retrieve all payment details on current month.
SELECT pay.pid,
pay.orderid,
pay.cusid,
pe.firstname || ' ' || pe.lastname AS Name,
pay.paydate AS "Date",
pay.payamount AS Amount,
pay.paymethod AS "Payment Method"
FROM payment pay JOIN person pe 
ON pay.cusid = pe.personid
WHERE pay.paydate BETWEEN TRUNC(sysdate, 'MONTH') AND LAST_DAY(sysdate)
ORDER BY "Date" ASC;

/* Function 1 */
-------Calculate the monthly salary for a part-time employee

CREATE OR REPLACE FUNCTION cal_parttimesalary
(empid parttime_employee.personid%TYPE)
RETURN EMPLOYEE.totalsalary%Type
IS 
salary EMPLOYEE.totalsalary%Type;
BEGIN
SELECT (hoursrate*weeklyworkhrs*4) INTO salary
FROM parttime_employee
WHERE personid = empid;
RETURN salary;
END;
/


----Calling a Function from an anonymous block
DECLARE
    parttime_salary EMPLOYEE.totalsalary%Type;
BEGIN
    parttime_salary := cal_parttimesalary('E011');
    
    DBMS_OUTPUT.PUT_LINE('Part-time employee salary: RM' || parttime_salary);
END;
/

/* Function 2 */
-------Calculate the total number of employees that are currently working according to employee type


CREATE OR REPLACE FUNCTION count_employees_by_type
(type IN employee.emptype%TYPE)
RETURN NUMBER
IS
    typenum NUMBER;
    keyintype employee.emptype%TYPE;
BEGIN
    keyintype := INITCAP(type);
    IF keyintype = 'Contract Employee' THEN
        SELECT COUNT(personid) INTO typenum
        FROM contract_employee
        WHERE contractenddate >= SYSDATE;
    ELSE
        SELECT COUNT(personid) INTO typenum
        FROM employee
        WHERE empType = type;
    END IF;

RETURN typenum;
END;
/

----Calling a Function from an anonymous block
DECLARE
    totalEmp NUMBER;
    empTypeToCount EMPLOYEE.empType%TYPE := 'Contract Employee'; 
BEGIN
    totalEmp := count_employees_by_type(empTypeToCount);
    
    DBMS_OUTPUT.PUT_LINE('The total number of ' || empTypeToCount || ' is ' || totalEmp);
END;
/

/* Function 3 */

-------Create a new food item ID

CREATE OR REPLACE FUNCTION create_itemid
RETURN FOODITEM.itemid%TYPE
IS
   numid NUMBER(3);
   currentid FOODITEM.itemid%TYPE;
   newid FOODITEM.itemid%TYPE;
BEGIN
    SELECT max(itemid) INTO currentid FROM fooditem;

    numid := TO_NUMBER(SUBSTR(currentid, 2, 3)) + 1;

    IF numid < 10 THEN
        newid := 'I00' || TO_CHAR(numid);
    ELSIF numid < 100 THEN
        newid := 'I0' || TO_CHAR(numid);
    ELSE
        newid := 'I' || TO_CHAR(numid);
    END IF;

    RETURN newid;
END;
/

/* Stored procedure 1 */
-------List the members whose membership will expire within a specified number of days

CREATE OR REPLACE PROCEDURE customer_orderHistory (
    cid member.personid%TYPE
)
IS
    CURSOR cus_cursor IS
        SELECT o.orderid, o.totalamount, o.discount, o.orderdate, o.ordertype, p.payamount, p.paymethod
        FROM order_s o
        JOIN payment p ON o.orderid = p.orderid
        WHERE o.cusid = cid;

    orid order_s.orderid%TYPE;
    tamount order_s.totalamount%TYPE;
    disc order_s.discount%TYPE;
    odate DATE;
    otype order_s.ordertype%TYPE;
    pmethod payment.paymethod%TYPE;
    pamount payment.payamount%TYPE;
    nom Number := 1;
BEGIN
    OPEN cus_cursor;

    DBMS_OUTPUT.PUT_LINE('Customer '||cid||' Order History ');
    DBMS_OUTPUT.PUT_LINE('============================================');

    LOOP
        FETCH cus_cursor INTO orid, tamount, disc, odate, otype, pamount, pmethod;
        EXIT WHEN cus_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(nom||'. Order ID : '|| orid);
        DBMS_OUTPUT.PUT_LINE('Total Amount: RM '||to_char(tamount,'999.99'));
        DBMS_OUTPUT.PUT_LINE('Discount: RM'||to_char(disc,'999.99'));
        DBMS_OUTPUT.PUT_LINE('Order Type: '||otype);
        DBMS_OUTPUT.PUT_LINE('Order Date: '|| odate);
        DBMS_OUTPUT.PUT_LINE('Total Payment Amount: RM '||to_char(pamount,'999.99'));
        DBMS_OUTPUT.PUT_LINE('Payment Method: '||pmethod);
        nom := nom + 1;
    END LOOP;

    CLOSE cus_cursor;
COMMIT;
END;
/

-----Executing Procedure
SET SERVEROUTPUT ON;
EXECUTE display_memberNearExp(30);

/* Stored procedure 2 */
------Add a new food item
------Run the create_itemid function before running the stored procedure, which is in function 3

CREATE OR REPLACE PROCEDURE insert_fooditem
(
new_foodcategoryid IN FOODITEM.foodcategoryid%TYPE,
new_foodname IN FOODITEM.foodname%TYPE,
new_foodunitprice IN FOODITEM.foodunitprice%TYPE,
new_fquantity IN FOODITEM.fquantity%TYPE
)
IS
	new_itemid FOODITEM.itemid%TYPE;

BEGIN
	new_itemid := create_itemid;
	INSERT INTO FOODITEM VALUES (new_itemid, new_foodcategoryid, new_foodname, new_foodunitprice, new_fquantity);

	UPDATE food_category
	SET itemno=itemno+1
	WHERE foodcategoryid = new_foodcategoryid;

	DBMS_OUTPUT.PUT_LINE('Food item is successfully inserted !');

COMMIT;
END;
/

-----Executing Procedure
SET SERVEROUTPUT ON;
EXECUTE insert_fooditem('F006','Strawberry Ice Cream Cake',10,30);

/* Stored procedure 3 */
-------Get customer order history

CREATE OR REPLACE PROCEDURE customer_orderHistory (
    cid member.personid%TYPE
)
IS
    CURSOR cus_cursor IS
        SELECT o.orderid, o.totalamount, o.discount, o.orderdate, o.ordertype, p.payamount, p.paymethod
        FROM order_s o
        JOIN payment p ON o.orderid = p.orderid
        WHERE o.cusid = cid;

    orid order_s.orderid%TYPE;
    tamount order_s.totalamount%TYPE;
    disc order_s.discount%TYPE;
    odate DATE;
    otype order_s.ordertype%TYPE;
    pmethod payment.paymethod%TYPE;
    pamount payment.payamount%TYPE;
    nom Number := 1;
BEGIN
    OPEN cus_cursor;

    DBMS_OUTPUT.PUT_LINE('Customer '||cid||' Order History ');
    DBMS_OUTPUT.PUT_LINE('============================================');

    LOOP
        FETCH cus_cursor INTO orid, tamount, disc, odate, otype, pamount, pmethod;
        EXIT WHEN cus_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(nom||'. Order ID : '|| orid);
        DBMS_OUTPUT.PUT_LINE('Total Amount: RM '||to_char(tamount,'999.99'));
        DBMS_OUTPUT.PUT_LINE('Discount: RM'||to_char(disc,'999.99'));
        DBMS_OUTPUT.PUT_LINE('Order Type: '||otype);
        DBMS_OUTPUT.PUT_LINE('Order Date: '|| odate);
        DBMS_OUTPUT.PUT_LINE('Total Payment Amount: RM '||to_char(pamount,'999.99'));
        DBMS_OUTPUT.PUT_LINE('Payment Method: '||pmethod);
        nom := nom + 1;
    END LOOP;

    CLOSE cus_cursor;
COMMIT;
END;
/


----Executing Procedure
SET SERVEROUTPUT ON;
EXECUTE customer_orderHistory('C032');

