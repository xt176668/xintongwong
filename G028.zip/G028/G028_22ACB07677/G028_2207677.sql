/*
File to submit by each member: G0999_9999999.sql

INDIVIDUAL ASSIGNMENT SUBMISSION
Submit one individual report with SQL statements only (*.docx)
and one sql script (*.sql for oOacle)

Template save as "G999_YourStudentID.sql"
e.g. G001_999999.sql

GROUP NUMBER : G028
PROGRAMME : CS
STUDENT ID :2207677
STUDENT NAME :WONG XIN TONG
Submission date and time: 14-04-2024

Your information should appear in both files one individual report docx & one individual sql script, then save as G01_99ACB999999.zip
Should be obvious different transaction among the members

*/



/* Query 1 */
SELECT c.personID, p.firstName, p.lastName, SUM(pay.payAmount) AS TotalSpent 

FROM CUSTOMER c 

JOIN PERSON p ON c.personID = p.personID 

JOIN PAYMENT pay ON c,personID = pay.cusID 

GROUP BY c.personID, p.firstName, p.lastName; 



/* Query 2 */
SELECT o.orderID, COUNT(oi.itemID) AS NumberOfItems 

FROM ORDER_S o 

JOIN ORDER_ITEM oi ON o.orderID = oi.orderID 

GROUP BY o.orderID 

HAVING COUNT (oi.itemID) > 1; 



/* Stored procedure 1 */
CREATE OR REPLACE PROCEDURE AddNewOrder( 

    p_orderID IN ORDER_S.orderID%TYPE, 

    p_cusID IN ORDER_S.cusID%TYPE, 

    p_empID IN ORDER_S.empID%TYPE, 

    p_orderType IN ORDER_S.orderType%TYPE, 

    p_orderDate IN ORDER_S.orderDate%TYPE, 

    p_itemID IN ORDER_ITEM.itemID%TYPE, 

    p_orderQuantity IN ORDER_ITEM.orderQuantity%TYPE, 

    p_orderPrice IN ORDER_ITEM.orderPrice%TYPE) 

IS 

BEGIN 

    INSERT INTO ORDER_S (orderID, cusID, empID, orderType, orderDate) 

    VALUES (p_orderID, p_cusID, p_empID, p_orderType, p_orderDate); 

  

    INSERT INTO ORDER_ITEM (orderID, itemID, orderPrice, orderQuantity) 

    VALUES (p_orderID, p_itemID, p_orderPrice, p_orderQuantity); 

  

    DBMS_OUTPUT.PUT_LINE('Order and Order Item Added Successfully. Order ID: ' || p_orderID); 

END; 

/ 


/* Stored procedure 2 */
CREATE OR REPLACE PROCEDURE UpdateTotalSalary( 

    p_personID IN EMPLOYEE.personID%TYPE, 

    p_newSalary IN EMPLOYEE.totalSalary%TYPE) 

IS 

BEGIN 

    UPDATE EMPLOYEE 

    SET totalSalary = p_newSalary 

    WHERE personID = p_personID; 

  

    -----output message----- 

    IF SQL%ROWCOUNT > 0 THEN 

        DBMS_OUTPUT.PUT_LINE('Salary Updated Successfully for Employee ID: ' || p_personID); 

    ELSE 

        DBMS_OUTPUT.PUT_LINE('No Employee Found with ID: ' || p_personID); 

    END IF; 

END; 

/ 


/* Function 1 */
CREATE OR REPLACE FUNCTION GetTotalOrdersByCustomer(p_cusID CUSTOMER.personID%TYPE) 

RETURN NUMBER 

IS 

   totalOrders NUMBER; 

BEGIN 

   SELECT COUNT(*) INTO totalOrders 

   FROM ORDER_S 

   WHERE cusID = p_cusID; 

  

   DBMS_OUTPUT.PUT_LINE('Total Orders for Customer ID ' || p_cusID || ' : ' || totalOrders); 

  

   RETURN totalOrders; 

END; 

/ 

/* Function 2 */
CREATE OR REPLACE FUNCTION GetCustomerType (p_personID CHAR) 

RETURN VARCHAR2 

IS 

    v_cusType CUSTOMER.cusType%TYPE; 

BEGIN 

    SELECT cusType INTO v_cusType FROM CUSTOMER WHERE personID = p_personID; 

  

    DBMS_OUTPUT.PUT_LINE('Customer Type for Person ID ' || p_personID || ': ' || v_cusType); 

  

    RETURN v_cusType; 

END; 

/ 